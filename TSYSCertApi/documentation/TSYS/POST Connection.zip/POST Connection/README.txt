This folder is a quickstart guide for integrating to Sierra/Summit platforms at TSYS using HTTP Post

If you encounter typos, omissions or need help with either this document or the TSYS message formats, please email:

    ACQ-Developer_Services@tsys.com

In this folder is two other files:

- A bare bones Haskell program that implements the minimum required to connect to us.

- A networkreq.txt file that contains a network trace of a bare minimum request that will generate a response. Note that unprintable characters are displayed as periods.

Broadly, there are a few steps to connecting for the 1080 and SGMF specifications:

1. You need to send a header of "Content-Type: x-Visa-II/x-auth"

2. The second character of your message is the Application Type. 4 is the only valid option for 1080/Summit POST connections, whereas 0 and 2 are legacy options for socket connections.

3. In the body of the POST request, you need to wrap your message in the ASCII characters STX & ETX, plus an LRC (Longitudal Redundancy Check)
   This would look like [STX]D4.999995123456789012...[ETX][LRC] for Sierra 1080
                        [STX]H4.TSH950<SGREQ><A1>999999999999999</A1>...</SGREQ>[ETX][LRC] for Summit

   LRC is calculated as an xor between all characters of the message plus ETX and it should be a single extra character you add to the end of the message.

If you are using the Sierra 1081, there are a few things specific to it:

1. You need to send a header of "Content-Type: x-Visa-II/x-settle"

2. All records that are not the final record need to use ETB instead of ETX:
   This would look like: [STX]Header[ETB][LRC]
                         [STX]Parameter[ETB][LRC]
                         [STX]Detail[ETB][LRC]
                         [STX]Trailer[ETX][LRC]
   In the actual request, new records do not have a newline seperating them, it is an LRC immediately followed by an STX.

3. The 2 character header is K1 instead of D4. Application Types of 3,5 and 6 are not needed for POST connections.

4. You should send your entire batch as one POST request. The maximum size of the request is 2MB. Batches in excess of this size should be split into multiple batches.
   
Connection Info:

https://ssltest2h.tsysacquiring.net/scripts/gateway.dll?transact port 15443

We have multiple subdomains that all lead to the same testing server if needed at:

ssltest2s.tsysacquiring.net
ssltest2h.tsysacquiring.net
ssltest.tsysacquiring.net

In addition, we have network logging enabled on port 443 if you need assistance troubleshooting your connection.
Please do not do general testing to the attended port to keep logs clear.
Provide your external IP address and timestamp if you need assistance.

Depending on the transaction type, you should wait the following times before assuming the connection has failed, as some issuers can take a long time to respond.

Credit Auth = 20 seconds
Debit Auth = 25 seconds
Capture = 30-60 seconds (depends on size of batch and time of day, e.g. a small retail store could do 30 seconds, but if you had many thousands of transactions from a large ecommerce setup, you would want to wait up to 60)